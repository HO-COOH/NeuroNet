This project is written in C++
This is a Visual Studio 2019 solution, if you have visual studio installed, simply open the .sln file and hit ctrl+F5 to run.
If you are on Windows, you can run the executable file in ./Debug/NeuroNet.exe
If you are using another operating system, use g++ to compile. I only used standard C++ library, so no extra flags are needed.

Directory Structure:
    ./NeuroNet.sln          Visual studio solution file
    ./Release/              ...The executable file
    ./NeuroNet/             The source code
